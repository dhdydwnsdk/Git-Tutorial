/* ****************
 *  일정 편집
 * ************** */

var editEvent = function (event, element, view) {

	$('#updateEvent').data('calendarId', event._id); //클릭한 이벤트 ID 아이디셋팅완료 ,.
    $('#deleteEvent').data('calendarId', event._id); //클릭한 이벤트 ID 아이디셋팅완료 ,. 

    $('.popover.fade.top').remove();
    $(element).popover("hide");

    if (event.allDay === true) {
        editAllDay.prop('checked', true);
    } else {
        editAllDay.prop('checked', false);
    }

    if (event.end === null) {
        event.end = event.start;
    }
    
    //이벤트 시작 시간이랑 끝나는시간이랑 같으면 에러
    if (event.allDay === true && event.end !== event.start) {
        editEnd.val(moment(event.end).subtract(1, 'days').format('YYYY-MM-DD'))
    } else {
        editEnd.val(event.end.format('YYYY-MM-DD'));
    }

    modalTitle.html('일정 수정');
    editTitle.val(event.title);
    editStart.val(event.start.format('YYYY-MM-DD'));
    editType.val(event.type);
    editDesc.val(event.description);
    editColor.val(event.backgroundColor).css('color', event.backgroundColor);
//아까거기서 서버 뭐선택임 ? 트래블스캔 ㅇㅇ
    addBtnContainer.hide();
    modifyBtnContainer.show();
    eventModal.modal('show');

  
    
    //페이지 f5로 새로고침하고 해봐
    //업데이트 버튼 클릭시
    $('#updateEvent').unbind();
    $('#updateEvent').on('click', function (e) {
    
    	
        if (editStart.val() > editEnd.val()) {
            alert('끝나는 날짜가 앞설 수 없습니다.');
            return false;
        }

        if (editTitle.val() === '') {
            alert('일정명은 필수입니다.')
            return false;
        }

        var statusAllDay;
        var startDate;
        var endDate;
        var displayDate;

        if (editAllDay.is(':checked')) {
            statusAllDay = true;
            startDate = moment(editStart.val()).format('YYYY-MM-DD');
            endDate = moment(editEnd.val()).format('YYYY-MM-DD');
            displayDate = moment(editEnd.val()).add(1, 'days').format('YYYY-MM-DD');
        } else {
            statusAllDay = false;
            startDate = editStart.val();
            endDate = editEnd.val();
            displayDate = endDate;
        }

        eventModal.modal('hide');
        alert('수정되었습니다.');
        
        
        event.allDay = statusAllDay;
        event.title = editTitle.val();
        event.start = startDate;
        event.end = displayDate;
        event.type = editType.val();
        event.backgroundColor = editColor.val();
        event.description = editDesc.val();

        $("#calendar").fullCalendar('updateEvent', event);
        
      
        //ajax
        
//        console.log=(calId);
//        console.dir=(calId);
//        console.dir=$(this).data().calendarId;
        $('form').attr('action','mypage?page=calendar&event=updateEvent');
        var calId = document.getElementById("calId");
    	calId.value=$(this).data().calendarId;
    	$('form').submit();
        //일정 업데이트
        /*$.ajax({
            type: "get",
            url: "",
            data: {
                //...
            },
            success: function (response) {
                alert('수정되었습니다.')
            }
        });
*/
    });
};
 

// 삭제버튼 아까 그 캘린더 어디임 ?이동해봐 마이페이지
$('#deleteEvent').on('click', function (e) {
	$('form').attr('action','mypage?page=calendar&event=deleteEvent');
	var calId = document.getElementById("calId");
	calId.value=$(this).data().calendarId;
	$('form').submit();
	eventModal.modal('hide');
	alert('삭제되었습니다.');

	
	
	//var formdataset = $('form');
	//formdataset.append('calendarId', event._id);
	//var calId = document.getElementById("calId").value;
	
	// calId 를 불러와서 val를 넣는다.
	//젖같은 이클립스 자바스크립트 자동완성도안되는 똥템 얼른 벗어나라 .
//	console.log(calId);
//	$('form').append('calendarId',e._id);
//	eventModal.modal('hide');
//	alret('삭제되었습니다.');
	//저장 ㄱㄱㄱ 
	//여기가 문제야 아 반응느려 ㅠㅠ 레이턴시 
	//전에는 되었잖아 뭐 만져서 그런것같은데
	//저거 삭제버튼맞지 ? 아니. ..왜 기능 한데몰빵함 좀 나눠하지 
	//읽기힘들게 ㅠㅠ 
	//ㅇㅇ
	//여기서 안먹혀
//    $('#deleteEvent').unbind();
  //  $("#calendar").fullCalendar('removeEvents', $(this).data('id'));
    //console.log($(this).data('id'));
  //  return false;
    //삭제시
//    $.ajax({
//        type: "get",
//        url: "",
//        data: {
//            //...
//        },
//        success: function (response) {
//            alert('삭제되었습니다.');
//        }
//    });

});