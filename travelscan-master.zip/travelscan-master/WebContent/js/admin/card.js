function cardClick(e) {
  $(e.target).parents(".card-item.admin")[0].classList.toggle("card-active");
  if($(e.target).parents(".card-item.admin")[0].children[0].disabled){
	  $(e.target).parents(".card-item.admin")[0].children[0].disabled = false;
  } else {
	  $(e.target).parents(".card-item.admin")[0].children[0].disabled = true;
  }
}

function filterCard(e) {
	// input text
	const text = e.target.value;
	const clearInput = document.querySelector(".clear-input");
	if(e.target.value !== ""){
		clearInput.classList.remove("hide");
	} else {
		clearInput.classList.add("hide");
	}
	// member
	const cardNames = document.querySelectorAll(".card-item .container .name");
	// members[0].innerText.slice(5)
	cardNames.forEach(cardName => {
		if(!cardName.innerText.slice(5).includes(text)){
			cardName.parentNode.parentNode.classList.add("hide");
		} else {
			cardName.parentNode.parentNode.classList.remove("hide");
		}
	})
}

function onClearInput(e){
	const input = document.querySelector(".card-search");
	input.value = "";
	const cardNames = document.querySelectorAll(".card-item .container .name");
	cardNames.forEach(cardName => {
		cardName.parentNode.parentNode.classList.remove("hide");
	})
	e.target.classList.add("hide");
}

function init() {
  const cards = document.querySelectorAll(".card-item.admin");
  if(cards){
	  for (let i = 0; i < cards.length; i++) {
		  cards[i].addEventListener("click", cardClick);
	  }  
  }
  const input = document.querySelector(".card-search");
  if(input)
	  input.addEventListener("keyup", filterCard);
  
  const clearInput = document.querySelector(".clear-input");
  if(clearInput){
	  clearInput.addEventListener("click", onClearInput);
	  clearInput.classList.add("hide");
  }
  
}

init();



