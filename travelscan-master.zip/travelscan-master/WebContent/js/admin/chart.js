function setAgeChart(ageList) {
	const data = [0,0,0,0,0,0];
	ageList.forEach(age => {
		data[(Number(age) / 10) - 1]++;
	})

	const ageCtx = document.getElementById("ageChart");
	if (ageCtx) {
		const ageChart = new Chart(ageCtx, {
			type : "bar",
			data : {
				labels : [ "10대", "20대", "30대", "40대", "50대", "60대" ],
				datasets : [
						{
							label : " 나이별 회원수",
							data,
							backgroundColor : [ "rgba(255, 99, 132, 0.2)",
									"rgba(54, 162, 235, 0.2)",
									"rgba(255, 206, 86, 0.2)",
									"rgba(75, 192, 192, 0.2)",
									"rgba(153, 102, 255, 0.2)",
									"rgba(255, 159, 64, 0.2)", ],
							borderColor : [ "rgba(255, 99, 132, 1)",
									"rgba(54, 162, 235, 1)",
									"rgba(255, 206, 86, 1)",
									"rgba(75, 192, 192, 1)",
									"rgba(153, 102, 255, 1)",
									"rgba(255, 159, 64, 1)", ],
							borderWidth : 1,
						}, ],
			},
			options : {
				scales : {
					yAxes : [ {
						ticks : {
							beginAtZero : true,
						},
					}, ],
				},
			},
		});
	}

}

function setGenderChart(genderList) {
	const data = [0,0];
	genderList.forEach(gender => {
		gender === "여" ? data[0]++ : data[1]++;
	})
	
	const genderCtx = document.getElementById("genderChart");
	if (genderCtx) {
		const genderChart = new Chart(genderCtx, {
			type : "pie",
			data : {
				labels : [ "여", "남" ],
				datasets : [
						{
							label : " 성별 비율",
							data,
							backgroundColor : [ "rgba(255, 99, 132, 0.2)",
									"rgba(54, 162, 235, 0.2)" ],
							borderColor : [ "rgba(255, 99, 132, 1)",
									"rgba(54, 162, 235, 1)" ],
							borderWidth : 1,
						}, ],
			},
			options : {
				scales : {
					yAxes : [ {
						ticks : {
							beginAtZero : true,
						},
					}, ],
				},
			},
		});
	}
}

function setRegionChart(regionList) {
	const region = ["서울", "인천", "부산", "대전", "광주", "대구", "울산", "경기도", "강원도", "충청북도", "충청남도", "전라북도", "전라남도", "경상북도", "경상남도", "제주", "세종"];
	const data = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];
	
	regionList.forEach(reg => {
		data[region.findIndex((v) => v === reg)]++;
	})
	
	
	const regionCtx = document.getElementById("regionChart");
	if (regionCtx) {
		const regionChart = new Chart(regionCtx, {
			type : "line",
			data : {
				labels : [...region],
				datasets : [
						{
							label : " 지역별 게시글",
							data,
							backgroundColor : "rgba(0,0,0,0)",
							borderColor : [ "rgba(255, 99, 132, 1)",
									"rgba(54, 162, 235, 1)",
									"rgba(255, 206, 86, 1)",
									"rgba(75, 192, 192, 1)",
									"rgba(153, 102, 255, 1)",
									"rgba(255, 159, 64, 1)", ],
							borderWidth : 1,
						}, ],
			},
			options : {
				scales : {
					yAxes : [ {
						ticks : {
							beginAtZero : true,
						},
					}, ],
				},
			},
		});
	}
}

function setCategoryChart(categoryList) {
	const category = ["축제","관광","음식","숙소"];
	const data = [0,0,0,0];
	
	categoryList.forEach(cat => {
		data[category.findIndex((v) => v === cat)]++;
	})
	
	const categoryCtx = document.getElementById("categoryChart");
	if (categoryCtx) {
		const categoryChart = new Chart(categoryCtx, {
			type : "line",
			data : {
				labels : [...category],
				datasets : [
						{
							label : " 분류별 게시글",
							data,
							backgroundColor : "rgba(0,0,0,0)",
							borderColor : [ "rgba(255, 99, 132, 1)",
									"rgba(54, 162, 235, 1)",
									"rgba(255, 206, 86, 1)",
									"rgba(75, 192, 192, 1)",
									"rgba(153, 102, 255, 1)",
									"rgba(255, 159, 64, 1)", ],
							borderWidth : 1,
						}, ],
			},
			options : {
				scales : {
					yAxes : [ {
						ticks : {
							beginAtZero : true,
						},
					}, ],
				},
			},
		});
	}
}