function addTableRow(e) {
	e.preventDefault();
	const tr = document.createElement("tr");
	const td1 = document.createElement("td");
	const td2 = document.createElement("td");
	const input = document.createElement("input");
	const idInput = document.createElement("input"); 
	
	if(e.target.classList[1] === "categoryAdd"){
		idInput.name = "categoryId";
		input.name = "categoryName";
	} else if(e.target.classList[1] === "regionAdd"){
		idInput.name = "regionId";
		input.name = "regionName";
	}
	
	idInput.type = "hidden";
	
	idInput.value = "-";
	
	input.classList.add("row-input");
	
	
	td1.innerText = "-";
	td1.appendChild(idInput);
	td2.appendChild(input);
	tr.classList.add("row-change-wait");
	tr.appendChild(td1);
	tr.appendChild(td2);
	const table = e.target.parentNode.nextElementSibling;
	table.appendChild(tr);
	input.focus();
	//document.body.scrollIntoView(false)
}

function saveTableRow(e){
	const target = e.target.classList[1];
	const form = document.querySelector("#updateMenuForm");
	form.action = "manager?event=updateMenu&target=" + target;
}

function onChangeRow(e) {
	if (e.target.defaultValue === e.target.value) {
		e.target.parentNode.parentNode.classList.remove("row-change-wait");
	} else {
		e.target.parentNode.parentNode.classList.add("row-change-wait");
	}
};

function init() {
	const rowInput = document.querySelectorAll(".row-input");
	if (rowInput.length > 0) {
		for (let i = 0; i < rowInput.length; i++) {
			rowInput[i].addEventListener("keyup", onChangeRow);
		}
	}
	const rowAddBtn = document.querySelectorAll(".row-add-btn");
	if (rowAddBtn.length > 0) {
		for (let i = 0; i < rowAddBtn.length; i++) {
			rowAddBtn[i].addEventListener("click", addTableRow)
		}
	}
	
	const rowSaveBtn = document.querySelectorAll(".row-save-btn");
	if(rowSaveBtn.length > 0){
		for(let i = 0; i < rowSaveBtn.length; i++){
			rowSaveBtn[i].addEventListener("click", saveTableRow);
		}
	}
}

init();