function toggleSidenav() {
  document.getElementById("mySidenav").classList.toggle("sidenav-active");
  document.querySelector(".main-container").classList.toggle("sidenav-active");
}

function init() {
  const sideOpenBtn = document.querySelector(".side-open-btn");
  const sideCloseBtn = document.querySelector(".side-close-btn");
  if(sideOpenBtn)
	  sideOpenBtn.addEventListener("click", toggleSidenav);
  if(sideCloseBtn)
	  sideCloseBtn.addEventListener("click", toggleSidenav);
  
  path = location.search;
  
  const sidenavList = document.querySelectorAll("#mySidenav a");
  for(let i = 0 ; i < sidenavList.length; i++){
	  if(sidenavList[i].search.includes(path)){
		  sidenavList[i].classList.add("sideList-active");
		  break;
	  }
  }
}

init();
