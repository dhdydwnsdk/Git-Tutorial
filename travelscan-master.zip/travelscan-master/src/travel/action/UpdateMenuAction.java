package travel.action;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import travel.dao.CategoriesDAO;
import travel.dao.RegionDAO;
import travel.dto.CategoriesDTO;
import travel.dto.RegionDTO;

public class UpdateMenuAction implements TravelActionImp{
	@Override
	public void execute(HttpServletRequest req) {
		String[] categoriesId = req.getParameterValues("categoryId");
		String[] categoriesName = req.getParameterValues("categoryName");
		String[] regionId = req.getParameterValues("regionId");
		String[] regionName = req.getParameterValues("regionName");
		
		String target = req.getParameter("target");
		
		if(target.equals("categorySave")) {
			System.out.println("updateCategory");
			if(categoriesId != null && categoriesId.length > 0) {
				CategoriesDAO catDao = CategoriesDAO.getInstance();
				
				List<CategoriesDTO> categoryUpdate = new ArrayList<CategoriesDTO>();
				List<CategoriesDTO> categoryInsert = new ArrayList<CategoriesDTO>();
				// System.out.println("categoriesId: " + categoriesId.length);
				for(int i = 0 ; i < categoriesId.length; i++) {
					// System.out.println(categoriesId[i] + categoriesName[i]);
					if(categoriesId[i].equals("-")) {
						categoryInsert.add(new CategoriesDTO(0, categoriesName[i]));
					} else {
						categoryUpdate.add(new CategoriesDTO(Integer.parseInt(categoriesId[i]), categoriesName[i]));
					}
				}
				 System.out.println("categoryInsert: " + categoryInsert.size());
				// System.out.println("categoryUpdate: " + categoryUpdate.size());
				if(categoryUpdate.size() > 0) {
					catDao.update(categoryUpdate);
				}
				if(categoryInsert.size() > 0) {
					catDao.insert(categoryInsert);
				}	
			}
		} else if(target.equals("regionSave")) {
			System.out.println("updateRegion");
			if(regionId != null && regionId.length > 0) {
				// System.out.println(regionId[0]);
				RegionDAO regDao = RegionDAO.getInstance();
				
				List<RegionDTO> regionUpdate = new ArrayList<RegionDTO>();
				List<RegionDTO> regionInsert = new ArrayList<RegionDTO>();
				
				for(int i = 0; i < regionId.length; i++) {
					if(regionId[i].equals("-")) {
						regionInsert.add(new RegionDTO(0, regionName[i]));
					} else {
						regionUpdate.add(new RegionDTO(Integer.parseInt(regionId[i]), regionName[i]));
					}
				}
				// System.out.println("regionInsert: " + regionInsert.size());
				// System.out.println("regionUpdate: " + regionUpdate.size());
				if(regionUpdate.size() > 0) {
					regDao.update(regionUpdate);
				}
				if(regionInsert.size() > 0) {
					regDao.insert(regionInsert);
				}
			}
		}
		
	}
	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) {
		
	}

}
