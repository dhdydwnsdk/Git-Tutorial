package travel.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import travel.dao.PostsDAO;

public class PostDeleteAction implements TravelActionImp {
	@Override
	public void execute(HttpServletRequest req) {
		String[] postId = req.getParameterValues("postId");
		if(postId != null && postId.length > 0) {
			PostsDAO dao = PostsDAO.getInstance();
			dao.deletePosts(postId);
		}
	}
	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) {
		
	}

}
