package travel.action;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import travel.dao.PostsDAO;
import travel.dto.PostDetailDTO;
import travel.dto.PostsDTO;

public class PostWriteAction implements TravelActionImp{

	@Override
	public void execute(HttpServletRequest req) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) {
	      PostsDAO dao= PostsDAO.getInstance();
	      PostsDTO dto= new PostsDTO();
	      dto.setTitle(req.getParameter("title"));
	      dto.setContents(req.getParameter("contents"));

	      
	      dao.insertMethod(dto);
	}

}