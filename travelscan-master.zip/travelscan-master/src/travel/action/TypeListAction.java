package travel.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;

import travel.dao.MateDAO;
import travel.dto.UsersDTO;

public class TypeListAction implements TravelActionImp {

	@Override
	public void execute(HttpServletRequest req) {
		MateDAO dao = MateDAO.getInstance();
		List<UsersDTO> bList = dao.mateTypeMethod();
		req.setAttribute("bList", bList);
	
		
		
	}

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) {
		// TODO Auto-generated method stub

	}

}
