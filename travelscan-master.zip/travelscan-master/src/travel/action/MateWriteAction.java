package travel.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;

import travel.dao.MateDAO;
import travel.dto.MateDTO;
import travel.dto.MateUserDTO;

public class MateWriteAction implements TravelActionImp{

		
	@Override
	public void execute(HttpServletRequest req) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) {
		
		MateDAO dao= MateDAO.getInstance();
		MateDTO dto= new MateDTO();
		
		dto.setName(req.getParameter("name"));
		dto.setEmail(req.getParameter("email"));
		dto.setCharacteristic(req.getParameter("character"));
		dto.setTitle(req.getParameter("title"));
		dto.setContents(req.getParameter("contents"));
		dao.insertMethod(dto);
		
	}

}//end class
