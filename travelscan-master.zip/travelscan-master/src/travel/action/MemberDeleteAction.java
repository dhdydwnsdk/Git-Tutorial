package travel.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import travel.dao.UsersDAO;

public class MemberDeleteAction implements TravelActionImp {
	@Override
	public void execute(HttpServletRequest req) {
		String members[] = req.getParameterValues("memberId");
		if (members != null && members.length > 0) {
			UsersDAO dao = UsersDAO.getInstance();
			dao.deleteUsers(members);
		}
	}

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) {

	}

}
