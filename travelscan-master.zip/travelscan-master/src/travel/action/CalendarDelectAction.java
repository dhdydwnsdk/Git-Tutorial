package travel.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import travel.dao.CalendarDAO;

public class CalendarDelectAction implements TravelActionImp{

	@Override
	public void execute(HttpServletRequest req) {
		CalendarDAO dao = CalendarDAO.getInstance();
		// calendarId 이새끼가 안넘어온다는데 ?  형식이 인티저 ㅡ, 즉 숫자로 넘어와야 한다는데 ? 잠만 
		//System.out.println(req.getParameter("calendarId").toString()+"번호 체크 아 스프링 조깥은거 ");
		System.out.println("ddddd : "+req.getParameter("calId"));
		int calendarId = Integer.parseInt(req.getParameter("calId"));
		dao.deleteMethod(calendarId);
	}

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) {
	
	}
	
}
