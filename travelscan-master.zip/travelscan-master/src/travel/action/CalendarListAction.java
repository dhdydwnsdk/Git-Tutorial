package travel.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import travel.dao.CalendarDAO;
import travel.dto.CalendarDTO;

public class CalendarListAction implements TravelActionImp {

	@Override
	public void execute(HttpServletRequest req) {
		CalendarDAO dao = CalendarDAO.getInstance();
		List<CalendarDTO> aList = dao.listMethod();
		req.setAttribute("aList", aList);
	}

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) {
		// TODO Auto-generated method stub

	}

}
