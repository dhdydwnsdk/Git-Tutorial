package travel.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import travel.dao.CategoriesDAO;
import travel.dao.RegionDAO;

public class PageMgrAction implements TravelActionImp {
	@Override
	public void execute(HttpServletRequest req) {
		CategoriesDAO catDao = CategoriesDAO.getInstance();
		RegionDAO regDao = RegionDAO.getInstance();
		req.setAttribute("categories", catDao.searchAll());
		req.setAttribute("regions", regDao.searchAll());
	}
	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) {
		
	}

}
