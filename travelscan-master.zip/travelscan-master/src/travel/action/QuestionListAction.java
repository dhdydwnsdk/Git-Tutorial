package travel.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import travel.dao.QuestionsDAO;

public class QuestionListAction implements TravelActionImp {
	@Override
	public void execute(HttpServletRequest req) {
		QuestionsDAO dao = QuestionsDAO.getInstance();
		req.setAttribute("questions", dao.searchAll());
	}
	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) {
		
	}
}
