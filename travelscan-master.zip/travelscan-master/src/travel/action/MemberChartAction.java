package travel.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import travel.dao.UsersDAO;

public class MemberChartAction implements TravelActionImp {
	@Override
	public void execute(HttpServletRequest req) {
		UsersDAO dao = UsersDAO.getInstance();
		req.setAttribute("members", dao.searchAll());
		
	}

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) {
		// TODO Auto-generated method stub

	}

}
