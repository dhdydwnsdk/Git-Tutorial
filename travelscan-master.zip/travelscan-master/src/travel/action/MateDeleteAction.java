package travel.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;

import travel.dao.MateDAO;
import travel.dto.MateDTO;

public class MateDeleteAction implements TravelActionImp {

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) {
		System.out.println(req.getParameter("mateId"));
		MateDAO dao = MateDAO.getInstance();
		int mateId = Integer.parseInt(req.getParameter("mateId"));
		dao.deleteMethod(mateId);

	}

	@Override
	public void execute(HttpServletRequest req) {
		// TODO Auto-generated method stub

	}

}// end class
