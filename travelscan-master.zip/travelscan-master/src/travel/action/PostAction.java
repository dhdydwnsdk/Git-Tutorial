package travel.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import travel.dao.PostsDAO;

public class PostAction implements TravelActionImp{
	@Override
	public void execute(HttpServletRequest req) {
		PostsDAO dao = PostsDAO.getInstance();
		req.setAttribute("posts", dao.searchAll());
	}
	
	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) {
		
	}

}
