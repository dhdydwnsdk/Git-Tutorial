package travel.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import travel.dao.QuestionsDAO;
import travel.dto.QuestionsDTO;

public class QuestionWriteAction implements TravelActionImp{

	@Override
	public void execute(HttpServletRequest req) {
		QuestionsDAO dao = QuestionsDAO.getInstance();
		QuestionsDTO dto = new QuestionsDTO();
		System.out.println("action값");
		dto.setEmail(req.getParameter("email"));
		dto.setName(req.getParameter("name"));
		dto.setTitle(req.getParameter("title"));
		dto.setContents(req.getParameter("contents"));
		dao.insertmethod(dto);
	}

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) {
		
	}

}
