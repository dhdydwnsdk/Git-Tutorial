package travel.action;


import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import travel.dao.CategoriesDAO;
import travel.dao.PostsDAO;
import travel.dao.RegionDAO;
import travel.dto.PostDetailDTO;
import travel.dto.PostsDTO;



public class PostListAction implements TravelActionImp{

	@Override
        public void execute(HttpServletRequest req) {
		PostsDAO dao = PostsDAO.getInstance();
		List<PostDetailDTO> aList=dao.searchAll();
	   // req.setAttribute( "song3" , dao.searchAll());
		req.setAttribute("aList", dao.searchAll());
	    RegionDAO dao2 =  RegionDAO.getInstance();
	    req.setAttribute("region", dao2.searchAll());
	    CategoriesDAO dao3 =  CategoriesDAO.getInstance();
	    req.setAttribute("categories", dao3.searchAll());
	    
	    
	}
	


@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) {

		
	}
}
