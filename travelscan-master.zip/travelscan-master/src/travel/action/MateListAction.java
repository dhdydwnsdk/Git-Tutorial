package travel.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import travel.dao.MateDAO;
import travel.dto.MateDTO;
import travel.dto.MateUserDTO;

public class MateListAction implements TravelActionImp {

	@Override
	public void execute(HttpServletRequest req) {
		MateDAO dao = MateDAO.getInstance();
		List<MateDTO> aList = dao.searchMateUser();
		req.setAttribute("aList", aList);

	}

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) {
		// TODO Auto-generated method stub

	}

}
