package travel.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import travel.dao.CalendarDAO;
import travel.dto.CalendarDTO;

public class CalendarInsertAction implements TravelActionImp {

	@Override
	public void execute(HttpServletRequest req) {
		CalendarDAO dao = CalendarDAO.getInstance();
		String title = req.getParameter("edit-title");
		String desc = req.getParameter("edit-desc");
		String start = req.getParameter("edit-start").split(" ")[0];
		String end = req.getParameter("edit-end").split(" ")[0];
		String type = req.getParameter("edit-type");
		String color = req.getParameter("color");
		System.out.println(desc);
		   
		CalendarDTO dto = new CalendarDTO();
		dto.setTitle(title);
		dto.setStartDate(start);
		dto.setEndDate(end);
		dto.setCategory(type);
		dto.setColorbar(color);
		dto.setContents(desc);

		dao.insertMethod(dto);
	}

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) {
		
	}

}
