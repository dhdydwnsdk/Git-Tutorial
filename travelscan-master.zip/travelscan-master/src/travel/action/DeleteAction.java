package travel.action;

import java.io.File;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import travel.dao.MediasDAO;
import travel.dao.PostsDAO;

public class DeleteAction implements TravelActionImp{

	@Override
	public void execute(HttpServletRequest req) {
		String saveDirectory="c:/tmp";
		
		MediasDAO mediadao = MediasDAO.getInstance();
		PostsDAO postdao = PostsDAO.getInstance();
		int num = Integer.parseInt(req.getParameter("postid"));
		
		System.out.println(num);
		String filename = mediadao.fileMethod(num);
		if (filename != null) {
			//board테이블의 첨부파일을 삭제
			File file = new File(saveDirectory, filename);
			file.delete();
		}
		postdao.deletePosts(num);
	}

	@Override  
	public void execute(HttpServletRequest req, HttpServletResponse res) {
		// TODO Auto-generated method stub
		
	}



}
