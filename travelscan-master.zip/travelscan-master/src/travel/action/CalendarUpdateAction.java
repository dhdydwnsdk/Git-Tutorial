package travel.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import travel.dao.CalendarDAO;
import travel.dto.CalendarDTO;

public class CalendarUpdateAction implements TravelActionImp{

	@Override
	public void execute(HttpServletRequest req) {
		CalendarDTO dto = new CalendarDTO();
		int calendarId = Integer.parseInt(req.getParameter("calId"));
		dto.setCalendarId(calendarId);
		//dto.setCalendarId(Integer.parseInt(req.getParameter("calId")));
		dto.setTitle(req.getParameter("edit-title"));
		dto.setStartDate(req.getParameter("edit-start").split(" ")[0]);
		dto.setEndDate(req.getParameter("edit-end").split(" ")[0]);
		dto.setCategory(req.getParameter("edit-type"));
		dto.setColorbar(req.getParameter("color"));
		dto.setContents(req.getParameter("edit-desc"));
		
		CalendarDAO dao= CalendarDAO.getInstance();
		dao.updateMethod(dto);
	}

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) {

		
		
	}
	
}
