package travel.action;

import java.io.File;
import java.io.IOException;
import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import travel.dao.MediasDAO;
import travel.dao.PostsDAO;
import travel.dto.MediasDTO;
import travel.dto.PostsDTO;

public class MediasAction implements TravelMultiImp {

	@Override
	public MultipartRequest executeMulti(HttpServletRequest req) {

		MultipartRequest multi = null;
		String saveDirectory = "c:/tmp";

		File file = new File(saveDirectory);
		if (!file.exists()) {
			file.mkdir();

		}
		int maxPostSize = 1000000000;
		; // 1GB
		String encoding = "UTF-8";

		try {
			multi = new MultipartRequest(req, saveDirectory, maxPostSize, encoding, new DefaultFileRenamePolicy());

		} catch (IOException e) {
			e.printStackTrace();
		}


		MediasDAO dao = MediasDAO.getInstance();
		MediasDTO dto = new MediasDTO();
		PostsDAO postDao = PostsDAO.getInstance();


		PostsDTO postDto = new PostsDTO();
		Enumeration params = multi.getParameterNames();
		while (params.hasMoreElements()) {
			String paramname = (String) params.nextElement();
			if(paramname.equalsIgnoreCase("title")) {
				String title = multi.getParameter("title");
				postDto.setTitle(multi.getParameter("title"));
			}
			if (paramname.equalsIgnoreCase("contents")) {
				String contents = multi.getParameter("contents");
				postDto.setContents(multi.getParameter("contents"));
			}
		}
		postDto.setRegionId(Integer.parseInt(multi.getParameter("region")));
		postDto.setCategoryId(Integer.parseInt(multi.getParameter("categories")));
		postDao.insertMethod(postDto);

		// postId 조회
		int postId = postDao.lastPostId();
		//
		
		dto.setPostId(postId);

		dto.setUrl(multi.getFilesystemName("filepath"));

		dao.insertMethod(dto);
		return multi;
	}
}
