package travel.dto;

import java.util.Date;

public class CalendarDTO {
	private int calendarId;
	private int userId;
	private String title;
	private String contents;
	private String startDate;
	private String endDate;
	private String colorbar;
	private String category;
	
	public CalendarDTO() {
	}

	public String getColorbar() {
		return colorbar;
	}

	public void setColorbar(String colorbar) {
		this.colorbar = colorbar;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public CalendarDTO(int calendarId, int userId, String title, String contents, String startDate, String endDate) {
		super();
		this.calendarId = calendarId;
		this.userId = userId;
		this.title = title;
		this.contents = contents;
		this.startDate = startDate;
		this.endDate = endDate;
	}

	public int getCalendarId() {
		return calendarId;
	}

	public void setCalendarId(int calendarId) {
		this.calendarId = calendarId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContents() {
		return contents;
	}

	public void setContents(String contents) {
		this.contents = contents;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

}
