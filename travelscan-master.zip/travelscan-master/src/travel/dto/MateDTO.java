package travel.dto;

import java.sql.Date;

public class MateDTO {
	private int mateId;
	private int userId;
	private String title;
	private String contents;
	private int count;
	private String character;
	private int liked;
	private Date createAt;
	private Date updateAt;
	private String name;
	private String email;
	private String characteristic;

	public MateDTO() {
	}



	public MateDTO(int mateId, int userId, String title, String contents, int count, String character, int liked,
			Date createAt, Date updateAt, String name, String email, String characteristic) {
		this.mateId = mateId;
		this.userId = userId;
		this.title = title;
		this.contents = contents;
		this.count = count;
		this.character = character;
		this.liked = liked;
		this.createAt = createAt;
		this.updateAt = updateAt;
		this.name = name;
		this.email = email;
		this.characteristic = characteristic;
	}



	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getCharacteristic() {
		return characteristic;
	}

	public void setCharacteristic(String characteristic) {
		this.characteristic = characteristic;
	}

	public Date getCreateAt() {
		return createAt;
	}

	public void setCreateAt(Date createAt) {
		this.createAt = createAt;
	}

	public Date getUpdateAt() {
		return updateAt;
	}

	public void setUpdateAt(Date updateAt) {
		this.updateAt = updateAt;
	}

	public int getMateId() {
		return mateId;
	}

	public void setMateId(int mateId) {
		this.mateId = mateId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContents() {
		return contents;
	}

	public void setContents(String contents) {
		this.contents = contents;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public String getCharacter() {
		return character;
	}

	public void setCharacter(String character) {
		this.character = character;
	}

	public int getLiked() {
		return liked;
	}

	public void setLiked(int liked) {
		this.liked = liked;
	}

}
