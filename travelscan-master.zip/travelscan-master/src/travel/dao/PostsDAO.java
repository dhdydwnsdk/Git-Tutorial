package travel.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;

import templatedbcp.DbcpTemplate;
import travel.dto.PostDetailDTO;
import travel.dto.PostsDTO;

public class PostsDAO {

	private Connection conn;
	private Statement stmt;
	private PreparedStatement pstmt;
	private ResultSet rs;

	private PostsDAO() {
		// TODO Auto-generated constructor stub
	}

	private static PostsDAO dao = new PostsDAO();

	public static PostsDAO getInstance() {
		return dao;
	}

	public List<PostDetailDTO> searchAll() {
		List<PostDetailDTO> aList = new ArrayList<PostDetailDTO>();

		try {
			conn = DbcpTemplate.getInit();
			stmt = conn.createStatement();
			String sql = "select p.postid, p.title, p.contents, p.count, p.likes, u.name as user_name, c.name as category_name, r.name as region_name, m.url as media_name\r\n" + 
					"from posts p, users u, categories c, region r, medias m\r\n" + 
					"where u.userid = p.userid\r\n" + 
					"and p.categoryid = c.categoryid\r\n" + 
					"and p.regionId = r.regionid\r\n" + 
					"and p.postid = m.postid(+) order by postid desc";
			rs = stmt.executeQuery(sql);
			while (rs.next()) {
				PostDetailDTO dto = new PostDetailDTO();
				dto.setPostId(rs.getInt("postId"));
				dto.setTitle(rs.getString("title"));
				dto.setContents(rs.getString("contents"));
				dto.setCount(rs.getInt("count"));
				dto.setLikes(rs.getInt("likes"));
				dto.setCategoryName(rs.getString("category_name"));
				dto.setRegionName(rs.getString("region_name"));
				dto.setUserName(rs.getString("user_name"));
				dto.setMediaName(rs.getString("media_name"));
				aList.add(dto);
			}
		} catch (NamingException | SQLException e) {
			e.printStackTrace();
		} finally {
			DbcpTemplate.close(rs);
			DbcpTemplate.close(stmt);
			DbcpTemplate.close(pstmt);
			DbcpTemplate.close(conn);
		}

		return aList;
	}
	
	public void deletePosts(String[] postId) {
		try {
			conn = DbcpTemplate.getInit();
			String sql = "DELETE FROM posts WHERE postid = ?";
			pstmt = conn.prepareStatement(sql);
			for(int i = 0 ;i  < postId.length; i++) {
				pstmt.setInt(1, Integer.parseInt(postId[i]));
				pstmt.addBatch();
			}
			pstmt.executeBatch();
		} catch (NamingException | SQLException e) {
			e.printStackTrace();
		} finally {
			DbcpTemplate.close(rs);
			DbcpTemplate.close(stmt);
			DbcpTemplate.close(pstmt);
			DbcpTemplate.close(conn);
		}
	}
	

	public void insertMethod(PostsDTO dto) {
		try {
			conn = DbcpTemplate.getInit();
			String sql = "INSERT INTO posts VALUES(posts_postid_seq.nextval,?,?,?,?,?,?,?,sysdate,sysdate)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, dto.getCategoryId());
			pstmt.setInt(2, 1);
			pstmt.setInt(3, dto.getRegionId());
			pstmt.setString(4, dto.getTitle());
			pstmt.setString(5, dto.getContents());
			pstmt.setInt(6, 4);
			pstmt.setInt(7, 5);
			pstmt.executeUpdate();
		} catch (NamingException | SQLException e) {
			e.printStackTrace();
		} finally {
			DbcpTemplate.close(rs);
			DbcpTemplate.close(pstmt);
			DbcpTemplate.close(conn);
			DbcpTemplate.close(stmt);
		}	
	}
	
	public int lastPostId() {
		int postId = -1;
		try {
			conn = DbcpTemplate.getInit();
			String sql = "select postid from (select * from posts order by postid desc) where rownum = 1";
			pstmt = conn.prepareStatement(sql);
            
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				postId = rs.getInt(1);
			}
			
			
		} catch (NamingException | SQLException e) {
			e.printStackTrace();
		} finally {
			DbcpTemplate.close(rs);
			DbcpTemplate.close(pstmt);
			DbcpTemplate.close(conn);
			DbcpTemplate.close(stmt);
		}	
	
		return postId;
	}
	public void deletePosts(int postid) {
		try {
			conn = DbcpTemplate.getInit();
			String sql = "DELETE FROM posts WHERE postid = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, postid);
			pstmt.executeUpdate();
			
		} catch (NamingException | SQLException e) {
			e.printStackTrace();
		} finally {
			DbcpTemplate.close(rs);
			DbcpTemplate.close(stmt);
			DbcpTemplate.close(pstmt);
			DbcpTemplate.close(conn);
		}

	}
	public void deleteimg(int postid) {
		try {
			conn = DbcpTemplate.getInit();
			String sql = "DELETE FROM medias WHERE postid = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, postid);
			pstmt.executeUpdate();

		} catch (NamingException | SQLException e) {
			e.printStackTrace();
		} finally {
			DbcpTemplate.close(rs);
			DbcpTemplate.close(stmt);
			DbcpTemplate.close(pstmt);
			DbcpTemplate.close(conn);
		}

	}

}
