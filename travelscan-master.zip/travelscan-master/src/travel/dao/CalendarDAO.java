package travel.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;

import com.sun.jmx.snmp.Timestamp;
import com.sun.org.apache.bcel.internal.generic.NEW;

import templatedbcp.DbcpTemplate;
import travel.dto.CalendarDTO;

public class CalendarDAO {

	private Connection conn;
	private Statement stmt;
	private PreparedStatement pstmt;
	private ResultSet rs;

	private CalendarDAO() {

	
	}

	private static CalendarDAO dao = new CalendarDAO();

	public static CalendarDAO getInstance() {
		return dao;
	}
	
	 public List<CalendarDTO> listMethod() { List<CalendarDTO> aList = new
			 ArrayList<CalendarDTO>();
			 
			 try { 
				 conn = DbcpTemplate.getInit(); 
				 String sql = "select * from calendar";
				 stmt = conn.createStatement(); 
				 rs = stmt.executeQuery(sql); 
				 while(rs.next())  { 
				 CalendarDTO dto = new CalendarDTO(); 
				 dto.setCalendarId(rs.getInt("calendarId"));
				 dto.setUserId(rs.getInt("userId")); 
				 dto.setTitle(rs.getString("title"));
				 dto.setStartDate(rs.getString("startDate"));
				 dto.setEndDate(rs.getString("endDate").split(" ")[0] + " 23:59:59");
				 dto.setContents(rs.getString("contents"));
				 dto.setColorbar(rs.getString("colorbar")); 
				 dto.setCategory(rs.getString("category")); 
				 aList.add(dto); 
				 } 
				 } catch (NamingException | SQLException e) {
					 e.printStackTrace(); 
			 	 } finally {
				 DbcpTemplate.close(rs);
				 DbcpTemplate.close(pstmt);
				 DbcpTemplate.close(stmt);
				 DbcpTemplate.close(conn);
				 }
			 return aList;
			 
			}//listMethod
	
	
	public void insertMethod(CalendarDTO dto) {
		try {
			conn = DbcpTemplate.getInit();
			String sql = "insert into calendar values (calendar_calenderid_seq.nextval,?,?,?,?,?,?,?)";
			pstmt= conn.prepareStatement(sql);
	
			
			pstmt.setInt(1, dto.getUserId());
			pstmt.setString(2, dto.getTitle());
			pstmt.setString(3, dto.getContents());
			pstmt.setDate(4, Date.valueOf(dto.getStartDate()));
			pstmt.setDate(5, Date.valueOf(dto.getEndDate()));
			pstmt.setString(6, dto.getColorbar());
			pstmt.setString(7, dto.getCategory());
			pstmt.executeUpdate();
		} catch (NamingException | SQLException e) {
			e.printStackTrace();
		} finally {
			DbcpTemplate.close(rs);
			DbcpTemplate.close(pstmt);
			DbcpTemplate.close(stmt);
			DbcpTemplate.close(conn);
		}
		
	}//insertMethod

	public void deleteMethod(int calendarId) {
		try {
			conn = DbcpTemplate.getInit();
			String sql = "delete from calendar where calendarid=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, calendarId);
			pstmt.executeUpdate();
			
			
		} catch (NamingException | SQLException e) {
			e.printStackTrace();
		} finally {
			DbcpTemplate.close(rs);
			DbcpTemplate.close(conn);
			DbcpTemplate.close(stmt);
			DbcpTemplate.close(pstmt);
		}
	}//deleteMethod
	
	
	public void updateMethod(CalendarDTO dto) {
		try {
			conn = DbcpTemplate.getInit();
			String sql = "update calendar set  title=?, contents=?, startdate=?, enddate=?, colorbar=?, category=? where calendarid=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, dto.getTitle());
			pstmt.setString(2, dto.getContents());
			pstmt.setDate(3, Date.valueOf(dto.getStartDate()));
			pstmt.setDate(4, Date.valueOf(dto.getEndDate()));
			pstmt.setString(5, dto.getColorbar());
			pstmt.setString(6, dto.getCategory());
			pstmt.setInt(7, dto.getCalendarId());
			pstmt.executeUpdate();
		} catch (NamingException | SQLException e) {
			e.printStackTrace();
		} finally {
			 DbcpTemplate.close(rs);
		     DbcpTemplate.close(pstmt);
		     DbcpTemplate.close(conn);
		     DbcpTemplate.close(stmt);
		}
		
	}//updateMethod
	
	
}
	

