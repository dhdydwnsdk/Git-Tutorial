package travel.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;

import templatedbcp.DbcpTemplate;
import travel.dto.CategoriesDTO;
import travel.dto.RegionDTO;

public class RegionDAO {

	private Connection conn;
	private Statement stmt;
	private PreparedStatement pstmt;
	private ResultSet rs;

	private RegionDAO() {
		// TODO Auto-generated constructor stub
	}

	private static RegionDAO dao = new RegionDAO();

	public static RegionDAO getInstance() {
		return dao;
	}
	
	public List<RegionDTO> searchAll() {
		List<RegionDTO> aList = new ArrayList<RegionDTO>();
		
		try {
			conn = DbcpTemplate.getInit();
			String sql = "SELECT * FROM region order by regionId";
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			while(rs.next()) {
				RegionDTO dto = new RegionDTO();
				dto.setRegionId(rs.getInt("regionId"));
				dto.setName(rs.getString("name"));
				aList.add(dto);
			}
		} catch (NamingException | SQLException e) {
			e.printStackTrace();
		} finally {
			DbcpTemplate.close(rs);
			DbcpTemplate.close(pstmt);
			DbcpTemplate.close(stmt);
			DbcpTemplate.close(conn);
		}
		
		return aList;
	}
	
	public void insert(List<RegionDTO> aList) {

		try {
			conn = DbcpTemplate.getInit();
			String sql = "INSERT INTO region VALUES (region_regionid_seq.nextval, ?)";
			pstmt = conn.prepareStatement(sql);
			for (int i = 0; i < aList.size(); i++) {
				pstmt.setString(1, aList.get(i).getName());
				pstmt.addBatch();
			}
			pstmt.executeBatch();
		} catch (NamingException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			DbcpTemplate.close(rs);
			DbcpTemplate.close(pstmt);
			DbcpTemplate.close(stmt);
			DbcpTemplate.close(conn);
		}
	}

	public void update(List<RegionDTO> aList) {

		try {
			conn = DbcpTemplate.getInit();
			String sql = "UPDATE region SET name = ? WHERE regionId = ?";
			pstmt = conn.prepareStatement(sql);
			for (int i = 0; i < aList.size(); i++) {
				pstmt.setString(1, aList.get(i).getName());
				pstmt.setInt(2, aList.get(i).getRegionId());
				pstmt.addBatch();
			}
			pstmt.executeBatch();
		} catch (NamingException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			DbcpTemplate.close(rs);
			DbcpTemplate.close(pstmt);
			DbcpTemplate.close(stmt);
			DbcpTemplate.close(conn);
		}
	}
	
}
