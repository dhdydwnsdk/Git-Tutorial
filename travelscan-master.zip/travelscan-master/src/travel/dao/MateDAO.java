package travel.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;

import templatedbcp.DbcpTemplate;
import travel.dto.MateDTO;
import travel.dto.MateUserDTO;
import travel.dto.UsersDTO;

public class MateDAO {

	private Connection conn;
	private Statement stmt;
	private PreparedStatement pstmt;
	private ResultSet rs;

	private MateDAO() {
	}

	private static MateDAO dao = new MateDAO();

	public static MateDAO getInstance() {
		return dao;
	}

	public List<MateUserDTO> listMethod() {// 조회하기
		//List<MateDTO> aList = new ArrayList<MateDTO>();
		List<MateUserDTO> aList= new ArrayList<MateUserDTO>();
		try {
			conn = DbcpTemplate.getInit();
			stmt = conn.createStatement();
			String sql = "SELECT * FROM mate";
			rs = stmt.executeQuery(sql);
			while (rs.next()) {
				//MateDTO dto = new MateDTO();
				MateUserDTO dto= new MateUserDTO();
				dto.setTitle(rs.getString("title"));
				dto.setMateId(rs.getInt("mateId"));
				dto.setContents(rs.getString("contents"));
				dto.setCreateAt(rs.getDate("createAt"));
				aList.add(dto);
			}
		} catch (NamingException | SQLException e) {
			e.printStackTrace();
		} finally {
			DbcpTemplate.close(rs);
			DbcpTemplate.close(pstmt);
			DbcpTemplate.close(conn);
			DbcpTemplate.close(stmt);
		}
		return aList;
	}// end listMethod

	public List<UsersDTO> mateTypeMethod() {// 타입 조회하기
		List<UsersDTO> bList = new ArrayList<UsersDTO>();
		try {	
			conn = DbcpTemplate.getInit();
			stmt = conn.createStatement();
			String sql = "SELECT * FROM users where userid=1";//userid 변경 필요
			rs = stmt.executeQuery(sql);
			while (rs.next()) {
			UsersDTO a = new UsersDTO();
				a.setCharacter(rs.getString("Character"));
				bList.add(a);
			}
		} catch (NamingException | SQLException e) {
			e.printStackTrace();
		} finally {
			DbcpTemplate.close(rs);
			DbcpTemplate.close(pstmt);
			DbcpTemplate.close(conn);
			DbcpTemplate.close(stmt);
		}
		return bList;
	}// end listMethod
	
	
	public List<UsersDTO> userListMethod() {// 타입 조회하기
		List<UsersDTO> cList = new ArrayList<UsersDTO>();
		try {
			conn = DbcpTemplate.getInit();
			stmt = conn.createStatement();
			String sql = "SELECT * FROM users ";
			rs = stmt.executeQuery(sql);
			while (rs.next()) {
			UsersDTO c = new UsersDTO();
				c.setCharacter(rs.getString("Character"));
				c.setEmail(rs.getString("email"));
				c.setInstagramId(rs.getString("instagramId"));
				c.setFacebookId(rs.getString("facebookId"));
				c.setTwitterId(rs.getString("twitterId"));
				cList.add(c);
			}
		} catch (NamingException | SQLException e) {
			e.printStackTrace();
		} finally {
			DbcpTemplate.close(rs);
			DbcpTemplate.close(pstmt);
			DbcpTemplate.close(conn);
			DbcpTemplate.close(stmt);
		}
		return cList;
	}// end listMethod
	
	
	
	public void insertMethod(MateDTO dto) {
		try {
			conn = DbcpTemplate.getInit();
			String sql = "INSERT INTO mate VALUES(mate_mateid_seq.nextval,?,?,1,1,1,sysdate,sysdate,?,?,?)"; // id
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, dto.getTitle());
			pstmt.setString(2, dto.getContents());
			pstmt.setString(3, dto.getName());
			pstmt.setString(4, dto.getEmail());
			pstmt.setString(5, dto.getCharacteristic());
			pstmt.executeUpdate();
		} catch (NamingException | SQLException e) {
			e.printStackTrace();
		} finally {
			DbcpTemplate.close(rs);
			DbcpTemplate.close(pstmt);
			DbcpTemplate.close(conn);
			DbcpTemplate.close(stmt);
		}

	}// end insertMethod

	public void deleteMethod(int mateId) {
		try {
			conn = DbcpTemplate.getInit();
			String sql = "DELETE FROM mate WHERE mateid=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, mateId);
			pstmt.executeUpdate();
		} catch (NamingException | SQLException e) {
			e.printStackTrace();
		} finally {
			DbcpTemplate.close(rs);
			DbcpTemplate.close(pstmt);
			DbcpTemplate.close(conn);
			DbcpTemplate.close(stmt);
		}
	
	}// end deleteMethod()

	// 캐릭터 입력
	public void updateCharcter(String character) {//추후 아이디 연동되면 수정 요망
		try {
			conn = DbcpTemplate.getInit();
			String sql = "update users set character=?";//userid 임의로 넣음 수정 요망 
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, character);
			//pstmt.setInt(2, dto.getUserId()); 로그인 연동시 수정 요망 
			pstmt.executeUpdate();
		} catch (NamingException | SQLException e) {
			e.printStackTrace();
		} finally {
			DbcpTemplate.close(rs);
			DbcpTemplate.close(pstmt);
			DbcpTemplate.close(conn);
			DbcpTemplate.close(stmt);
		}
	}//end updateCharacter
	
	public List<MateDTO> searchMateUser() {//사용자 더보기 조회
		List<MateDTO> aList = new ArrayList<MateDTO>();
		try {
			conn = DbcpTemplate.getInit();
			stmt = conn.createStatement();
			String sql = "select * from mate order by mateid desc";
			rs = stmt.executeQuery(sql);
			while (rs.next()) {
				MateDTO dto = new MateDTO();
				dto.setTitle(rs.getString("title"));
				dto.setMateId(rs.getInt("mateId"));
				dto.setContents(rs.getString("contents"));
				dto.setCreateAt(rs.getDate("createAt"));
				dto.setEmail(rs.getString("email"));
				dto.setName(rs.getString("name"));
				dto.setCharacteristic(rs.getString("characteristic"));
				aList.add(dto);
			}
		} catch (NamingException | SQLException e) {
			e.printStackTrace();
		} finally {
			DbcpTemplate.close(rs);
			DbcpTemplate.close(pstmt);
			DbcpTemplate.close(conn);
			DbcpTemplate.close(stmt);
		}
		return aList;
	}

	public void updateMethod(MateDTO dto) {
		   try {
				conn = DbcpTemplate.getInit();
				String sql = "UPDATE mate SET title=?, contents=?, updateat=sysdate WHERE mateid=?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, dto.getTitle());
				pstmt.setString(2, dto.getContents());
				pstmt.setInt(3, dto.getMateId());
				pstmt.executeUpdate();
			} catch (NamingException | SQLException e) {
				e.printStackTrace();
			} finally {
				 DbcpTemplate.close(rs);
			     DbcpTemplate.close(pstmt);
			     DbcpTemplate.close(conn);
			     DbcpTemplate.close(stmt);
			}
			   
		   }//end updateMethod()/////////

}
