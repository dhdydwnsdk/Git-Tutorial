package travel.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;

import templatedbcp.DbcpTemplate;
import travel.dto.QuestionsDTO;

public class QuestionsDAO {

	private Connection conn;
	private Statement stmt;
	private PreparedStatement pstmt;
	private ResultSet rs;

	private QuestionsDAO() {
		// TODO Auto-generated constructor stub
	}

	private static QuestionsDAO dao = new QuestionsDAO();

	public static QuestionsDAO getInstance() {
		return dao;
	}
	
	public void insertmethod(QuestionsDTO dto) {
		try {
			conn = DbcpTemplate.getInit();
			String sql = "INSERT INTO questions VALUES(QUESTIONS_ADMINID_SEQ.nextval,?,?,?,?)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, dto.getEmail());
			pstmt.setString(2, dto.getName());
			pstmt.setString(3, dto.getTitle());
			pstmt.setString(4, dto.getContents());
			pstmt.executeUpdate();
		} catch (NamingException | SQLException e) {
			e.printStackTrace();
		} finally {
			DbcpTemplate.close(rs);
			DbcpTemplate.close(conn);
			DbcpTemplate.close(stmt);
			DbcpTemplate.close(pstmt);
		}

	}// end insertMethod()

	public List<QuestionsDTO> searchAll() {
		List<QuestionsDTO> aList = new ArrayList<QuestionsDTO>();
		
		try {
			conn = DbcpTemplate.getInit();
			String sql = "select * from questions order by adminid";
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			while(rs.next()) {
				QuestionsDTO dto = new QuestionsDTO();
				dto.setAdminId(rs.getInt("adminId"));
				dto.setEmail(rs.getString("email"));
				dto.setName(rs.getString("name"));
				dto.setTitle(rs.getString("title"));
				dto.setContents(rs.getString("contents"));
				aList.add(dto);
			}
		} catch (NamingException | SQLException e) {
			e.printStackTrace();
		} finally {
			DbcpTemplate.close(rs);
			DbcpTemplate.close(pstmt);
			DbcpTemplate.close(stmt);
			DbcpTemplate.close(conn);
		}
		return aList;
	}
}
