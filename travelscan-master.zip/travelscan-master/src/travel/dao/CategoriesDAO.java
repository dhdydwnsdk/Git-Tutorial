package travel.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;

import templatedbcp.DbcpTemplate;
import travel.dto.CategoriesDTO;

public class CategoriesDAO {

	private Connection conn;
	private Statement stmt;
	private PreparedStatement pstmt;
	private ResultSet rs;

	private CategoriesDAO() {
		// TODO Auto-generated constructor stub
	}

	private static CategoriesDAO dao = new CategoriesDAO();

	public static CategoriesDAO getInstance() {
		return dao;
	}

	public List<CategoriesDTO> searchAll() {
		List<CategoriesDTO> aList = new ArrayList<CategoriesDTO>();

		try {
			conn = DbcpTemplate.getInit();
			String sql = "SELECT * FROM categories order by categoryId";
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			while (rs.next()) {
				CategoriesDTO dto = new CategoriesDTO();
				dto.setCategoryId(rs.getInt("categoryId"));
				dto.setName(rs.getString("name"));
				aList.add(dto);
			}
		} catch (NamingException | SQLException e) {
			e.printStackTrace();
		} finally {
			DbcpTemplate.close(rs);
			DbcpTemplate.close(pstmt);
			DbcpTemplate.close(stmt);
			DbcpTemplate.close(conn);
		}

		return aList;
	}

	public void insert(List<CategoriesDTO> aList) {

		try {
			conn = DbcpTemplate.getInit();
			String sql = "INSERT INTO categories VALUES (categories_categoryid_seq.nextval, ?)";
			pstmt = conn.prepareStatement(sql);
			for (int i = 0; i < aList.size(); i++) {
				pstmt.setString(1, aList.get(i).getName());
				pstmt.addBatch();
			}
			pstmt.executeBatch();
		} catch (NamingException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			DbcpTemplate.close(rs);
			DbcpTemplate.close(pstmt);
			DbcpTemplate.close(stmt);
			DbcpTemplate.close(conn);
		}
	}

	public void update(List<CategoriesDTO> aList) {

		try {
			conn = DbcpTemplate.getInit();
			String sql = "UPDATE categories SET name = ? WHERE categoryId = ?";
			pstmt = conn.prepareStatement(sql);
			for (int i = 0; i < aList.size(); i++) {
				pstmt.setString(1, aList.get(i).getName());
				pstmt.setInt(2, aList.get(i).getCategoryId());
				pstmt.addBatch();
			}
			pstmt.executeBatch();
		} catch (NamingException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			DbcpTemplate.close(rs);
			DbcpTemplate.close(pstmt);
			DbcpTemplate.close(stmt);
			DbcpTemplate.close(conn);
		}
	}

}
