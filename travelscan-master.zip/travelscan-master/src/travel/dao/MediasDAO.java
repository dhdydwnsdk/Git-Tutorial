package travel.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;

import templatedbcp.DbcpTemplate;
import travel.dto.MediasDTO;

public class MediasDAO {

	private Connection conn;
	private Statement stmt;
	private PreparedStatement pstmt;
	private ResultSet rs;

	private MediasDAO() {
		// TODO Auto-generated constructor stub
	}

	private static MediasDAO dao = new MediasDAO();

	public static MediasDAO getInstance() {
		return dao;
	}
	//파일 가져오기?
		public void insertMethod(MediasDTO dto) {
			try {
				conn = DbcpTemplate.getInit();

				String sql = "INSERT INTO Medias VALUES(MEDIAS_MEDIAID_SEQ.nextval,?,?,null)";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, dto.getPostId());
				pstmt.setString(2, dto.getUrl());
				pstmt.executeUpdate();
			} catch (NamingException | SQLException e) {
				e.printStackTrace();
			} finally {
				DbcpTemplate.close(rs);
				DbcpTemplate.close(conn);
				DbcpTemplate.close(stmt);
				DbcpTemplate.close(pstmt);
			}
		}
		
		//파일업로드?
		public String fileMethod(int postid) {

			String fileName = null;
			try {
				conn = DbcpTemplate.getInit();
				String sql = "select url from medias where postid=?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, postid);
				rs = pstmt.executeQuery();
				if (rs.next())
					fileName = rs.getString("url");
			} catch (NamingException | SQLException e) {
				e.printStackTrace();
			} finally {
				DbcpTemplate.close(rs);
				DbcpTemplate.close(conn);
				DbcpTemplate.close(stmt);
				DbcpTemplate.close(pstmt);
			}

			return fileName;

		}
	    //???????
		public List<MediasDTO> selectMethod() {
			List<MediasDTO> aList = new ArrayList<MediasDTO>();

			try {
				conn = DbcpTemplate.getInit();
				String sql = "SELECT * FROM Medias ORDER BY num DESC";
				pstmt = conn.prepareStatement(sql);
				rs = pstmt.executeQuery();
				while (rs.next()) {
					MediasDTO dto = new MediasDTO();
					dto.setMediaId(rs.getInt("mediaid"));
					dto.setPostId(rs.getInt("postid"));
					dto.setUrl(rs.getString("url"));
			
					aList.add(dto);
				}

			} catch (NamingException | SQLException e) {
				e.printStackTrace();
			} finally {
				DbcpTemplate.close(rs);
				DbcpTemplate.close(conn);
				DbcpTemplate.close(stmt);
				DbcpTemplate.close(pstmt);
			}
			return aList;


		
		}//end fileList
	
	
}
