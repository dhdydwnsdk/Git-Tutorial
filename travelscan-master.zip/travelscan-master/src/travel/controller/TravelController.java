package travel.controller;

import java.io.IOException;
import java.net.URLEncoder;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import travel.action.CalendarDelectAction;
import travel.action.CalendarInsertAction;
import travel.action.CalendarListAction;
import travel.action.CalendarUpdateAction;
import travel.action.DeleteAction;
import travel.action.MateDeleteAction;
import travel.action.MateListAction;
import travel.action.MateWriteAction;
import travel.action.MediasAction;
import travel.action.MemberAction;
import travel.action.MemberChartAction;
import travel.action.MemberDeleteAction;
import travel.action.PageMgrAction;
import travel.action.PostAction;
import travel.action.PostChartAction;
import travel.action.PostDeleteAction;
import travel.action.PostListAction;
import travel.action.QuestionListAction;
import travel.action.QuestionWriteAction;
import travel.action.TypeListAction;
import travel.action.UpdateMenuAction;

@WebServlet("/travel/*")
public class TravelController extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		doProcess(req, res);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		doProcess(req, res);
	}

	protected void doProcess(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		req.setCharacterEncoding("UTF-8");
		String uri = req.getRequestURI();
		// System.out.println(uri);

		String action = uri.substring(uri.lastIndexOf("/") + 1);
		System.out.println(action);

		String next = "";

		if (action.equals("*")) {
			next = "/pages/index.jsp";
		} else if (action.equals("manager")) {
			String search = req.getParameter("page");
			String event = req.getParameter("event");
			if (event != null) {
				if (event.equals("deleteMember")) {
					MemberDeleteAction memberDelete = new MemberDeleteAction();
					memberDelete.execute(req);
					res.sendRedirect("manager?page=member");
				} else if (event.equals("updateMenu")) {
					UpdateMenuAction updateMenu = new UpdateMenuAction();
					updateMenu.execute(req);
					res.sendRedirect("manager?page=pageMgr");
				} else if (event.equals("deletePost")) {
					PostDeleteAction postDelete = new PostDeleteAction();
					postDelete.execute(req);
					res.sendRedirect("manager?page=post");
				}
			} else {
				next = "/pages/manager.jsp";
				if (search.equals("member")) {
					MemberAction memAct = new MemberAction();
					memAct.execute(req);
				} else if (search.equals("memberChart")) {
					MemberChartAction memChartAct = new MemberChartAction();
					memChartAct.execute(req);
				} else if (search.equals("post")) {
					PostAction postAct = new PostAction();
					postAct.execute(req);
				} else if (search.equals("postChart")) {
					PostChartAction postChartAct = new PostChartAction();
					postChartAct.execute(req);
				} else if (search.equals("question")) {
					QuestionListAction queAct = new QuestionListAction();
					queAct.execute(req);
				} else if (search.equals("pageMgr")) {
					PageMgrAction pageMgr = new PageMgrAction();
					pageMgr.execute(req);
				}
			}
		} else if (action.equals("mypage")) {
			String search = req.getParameter("page");
			String event = req.getParameter("event");
			if (event != null) {

				if (event.equals("addEvent")) {
					CalendarInsertAction calIn = new CalendarInsertAction();
					calIn.execute(req);
					res.sendRedirect("mypage?page=calendar");
				} else if (event.equals("updateEvent")) {
					CalendarUpdateAction calUp = new CalendarUpdateAction();
					calUp.execute(req);
					res.sendRedirect("mypage?page=calendar");
				} else if (event.equals("deleteEvent")) {
					CalendarDelectAction calDe = new CalendarDelectAction();
					calDe.execute(req);
					res.sendRedirect("mypage?page=calendar");
				}
			} else {
				next = "/pages/mypage.jsp";
				if (search.equals("calendar")) {
					CalendarListAction CalLi = new CalendarListAction();
					CalLi.execute(req);
				}
			}

		} else if (action.equals("mate")) {
			String search = req.getParameter("page");
			String event = req.getParameter("event");
			if (event != null) {

			} else {
				next = "/pages/matePage.jsp";
				if (search.equals("board")) {
					MateListAction matelist = new MateListAction();// 게시 글 보여주는 애
					TypeListAction typelist = new TypeListAction();// 힐링형 붙여주는 애
					matelist.execute(req);
					typelist.execute(req);
				}
			}
		} else if (action.equals("writemate")) {
			MateWriteAction matewrite = new MateWriteAction();
			matewrite.execute(req, res);
			String character = URLEncoder.encode(req.getParameter("character"));
			res.sendRedirect("mate?page=board&character=" + character);
		} else if (action.equals("deleteMate")) {
			MateDeleteAction matedelete = new MateDeleteAction();
			matedelete.execute(req, res);
			String character = URLEncoder.encode(req.getParameter("character"));
			res.sendRedirect("mate?page=board&character=" + character);
		} else if (action.equals("contact")) {
			next = "/pages/contact.jsp";
		} else if (action.equals("writeContact")) {
			QuestionWriteAction qform = new QuestionWriteAction();
			qform.execute(req);
			res.sendRedirect("contact");
		} else if (action.equals("postwrite")) {
			MediasAction MediasAct = new MediasAction();
			MediasAct.executeMulti(req);
			res.sendRedirect("board");
		} else if (action.equals("board")) {
			// PostListAction
			// DB에서 Post List 조회해서 가져옴
			PostListAction postAct = new PostListAction();
			postAct.execute(req);
			next = "/pages/board.jsp";
		} else if (action.equals("deletePost")) {
			DeleteAction deleteAct = new DeleteAction();
			deleteAct.execute(req);
			res.sendRedirect("board");
		}

		if (!next.equals("")) {
			RequestDispatcher dis = req.getRequestDispatcher(next);
			dis.forward(req, res);
		}
	}

}
